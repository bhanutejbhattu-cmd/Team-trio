"""Hybrid Chess Engine: High-performance Stockfish with seamless Pure-Python fallback.

Architecture:
1. Evaluates position using Stockfish when permitted, functional, and healthy.
2. Automatically detects sandboxed environments where subprocess execution, compiled binaries,
   or incompatible architectures prevent Stockfish from starting.
3. Automatically falls back to the built-in 0x88 pure-Python alpha-beta engine upon:
   - Missing executable
   - Architecture mismatch (e.g. Windows .exe on Linux server)
   - Process permission denied or sandbox seccomp restrictions
   - Subprocess crash or search timeout
   - Engine returning an invalid or illegal move
4. Guarantees 100% legal moves under all operational conditions.
"""

import sys
from typing import Optional, List, Union, Tuple, Any

from engine.board import Board, START_FEN
from engine.search import Search
from engine.stockfish_adapter import StockfishAdapter, StockfishError

# Optional python-chess support for platforms that pass chess.Board directly
try:
    import chess
    HAS_PYTHON_CHESS = True
except ImportError:
    HAS_PYTHON_CHESS = False


class HybridEngine:
    """Orchestrates move selection across Stockfish and the pure-Python search engine."""

    def __init__(
        self,
        enable_stockfish: bool = True,
        stockfish_path: Optional[str] = None,
        threads: int = 1,
        hash_mb: int = 16,
    ):
        self.pure_search = Search()
        self.enable_stockfish = enable_stockfish
        self.stockfish: Optional[StockfishAdapter] = None
        self.last_engine_used: str = "none"

        if enable_stockfish:
            adapter = StockfishAdapter(binary_path=stockfish_path, threads=threads, hash_mb=hash_mb)
            if adapter.is_available():
                self.stockfish = adapter
                print(f"[HybridEngine] Initialized with primary engine: {adapter.engine_name}", file=sys.stderr)
            else:
                print("[HybridEngine] Stockfish unavailable or incompatible. Using pure-Python engine.", file=sys.stderr)

    def is_stockfish_active(self) -> bool:
        """Returns True if Stockfish is configured and available."""
        return self.stockfish is not None and self.enable_stockfish

    def choose_move(
        self,
        board_or_fen: Any,
        time_ms: int = 150,
        depth: Optional[int] = None,
    ) -> str:
        """Computes the best move for the given board representation.

        Args:
            board_or_fen: An engine.board.Board, chess.Board, or FEN string.
            time_ms: Time limit in milliseconds.
            depth: Optional fixed search depth.

        Returns:
            Move in UCI string format (e.g. 'e2e4').
        """
        fen, legal_uci_moves, pure_board = self._normalize_board(board_or_fen)

        if not legal_uci_moves:
            return ""  # Terminal game state (checkmate or stalemate)

        # 1. Attempt Stockfish move if enabled
        if self.is_stockfish_active():
            try:
                # Reserve 20ms safety margin for process communication
                sf_time = max(10, time_ms - 20)
                move_uci = self.stockfish.get_best_move(fen, movetime_ms=sf_time, depth=depth)
                if move_uci in legal_uci_moves:
                    self.last_engine_used = "stockfish"
                    return move_uci
                else:
                    print(
                        f"[HybridEngine WARNING] Stockfish returned illegal move '{move_uci}'. Falling back to pure Python.",
                        file=sys.stderr,
                    )
            except (StockfishError, Exception) as err:
                print(
                    f"[HybridEngine WARNING] Stockfish error: {err}. Falling back to pure Python.",
                    file=sys.stderr,
                )

        # 2. Pure-Python Fallback Engine
        self.last_engine_used = "pure_python"
        try:
            best_move_int = self.pure_search.search(
                pure_board,
                time_ms=time_ms,
                max_depth=depth or 64,
            )
            if best_move_int is not None:
                move_uci = pure_board.move_to_uci(best_move_int)
                if move_uci in legal_uci_moves:
                    return move_uci
        except Exception as err:
            print(f"[HybridEngine ERROR] Pure search error: {err}", file=sys.stderr)

        # 3. Fail-safe fallback: return the first legal move
        fallback_move = legal_uci_moves[0]
        print(f"[HybridEngine ALERT] Using legal fallback move '{fallback_move}'.", file=sys.stderr)
        return fallback_move

    def _normalize_board(self, board_or_fen: Any) -> Tuple[str, List[str], Board]:
        """Normalizes various board representations into (fen, legal_uci_moves, pure_board)."""
        if isinstance(board_or_fen, str):
            fen = board_or_fen.strip()
            pure_board = Board(fen)
            legal_moves = [pure_board.move_to_uci(m) for m in pure_board.legal_moves()]
            return fen, legal_moves, pure_board

        if HAS_PYTHON_CHESS and isinstance(board_or_fen, chess.Board):
            fen = board_or_fen.fen()
            legal_moves = [m.uci() for m in board_or_fen.legal_moves]
            pure_board = Board(fen)
            return fen, legal_moves, pure_board

        if isinstance(board_or_fen, Board):
            fen = board_or_fen.to_fen()
            legal_moves = [board_or_fen.move_to_uci(m) for m in board_or_fen.legal_moves()]
            return fen, legal_moves, board_or_fen

        # Generic object with .fen() or .to_fen()
        if hasattr(board_or_fen, "fen"):
            fen = board_or_fen.fen()
        elif hasattr(board_or_fen, "to_fen"):
            fen = board_or_fen.to_fen()
        else:
            fen = START_FEN

        pure_board = Board(fen)
        legal_moves = [pure_board.move_to_uci(m) for m in pure_board.legal_moves()]
        return fen, legal_moves, pure_board

    def new_game(self) -> None:
        """Resets engine state for a new game."""
        self.pure_search.new_game()
        if self.stockfish:
            try:
                self.stockfish._send_command("ucinewgame")
            except Exception:
                pass

    def close(self) -> None:
        """Shuts down all engine processes."""
        if self.stockfish:
            self.stockfish.stop()
            self.stockfish = None

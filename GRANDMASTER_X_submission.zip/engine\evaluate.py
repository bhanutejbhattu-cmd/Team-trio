"""Evaluation function for the AI KNOCOUT chess engine.

Returns a score in centipawns from the perspective of the side to move
(negamax convention): positive means the side to move is better.

Includes: material, tapered piece-square tables, bishop pair, pawn
structure (doubled / isolated / passed), rook file activity, king pawn
shield, and mobility.
"""

from engine.board import (
    WHITE, BLACK, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING,
    BISHOP_OFFSETS, ROOK_OFFSETS, KING_OFFSETS, KNIGHT_OFFSETS,
)

# --- Material values (middlegame, endgame) --------------------------------
MG_VALUE = {PAWN: 82, KNIGHT: 337, BISHOP: 365, ROOK: 477, QUEEN: 1025, KING: 0}
EG_VALUE = {PAWN: 94, KNIGHT: 281, BISHOP: 297, ROOK: 512, QUEEN: 936, KING: 0}

PHASE_WEIGHT = {PAWN: 0, KNIGHT: 1, BISHOP: 1, ROOK: 2, QUEEN: 4, KING: 0}
TOTAL_PHASE = 24

# --- Piece-square tables (given a8-first, converted to a1-first) ----------
_PAWN = [
     0,  0,  0,  0,  0,  0,  0,  0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
     5,  5, 10, 25, 25, 10,  5,  5,
     0,  0,  0, 20, 20,  0,  0,  0,
     5, -5,-10,  0,  0,-10, -5,  5,
     5, 10, 10,-20,-20, 10, 10,  5,
     0,  0,  0,  0,  0,  0,  0,  0,
]
_KNIGHT = [
   -50,-40,-30,-30,-30,-30,-40,-50,
   -40,-20,  0,  0,  0,  0,-20,-40,
   -30,  0, 10, 15, 15, 10,  0,-30,
   -30,  5, 15, 20, 20, 15,  5,-30,
   -30,  0, 15, 20, 20, 15,  0,-30,
   -30,  5, 10, 15, 15, 10,  5,-30,
   -40,-20,  0,  5,  5,  0,-20,-40,
   -50,-40,-30,-30,-30,-30,-40,-50,
]
_BISHOP = [
   -20,-10,-10,-10,-10,-10,-10,-20,
   -10,  0,  0,  0,  0,  0,  0,-10,
   -10,  0,  5, 10, 10,  5,  0,-10,
   -10,  5,  5, 10, 10,  5,  5,-10,
   -10,  0, 10, 10, 10, 10,  0,-10,
   -10, 10, 10, 10, 10, 10, 10,-10,
   -10,  5,  0,  0,  0,  0,  5,-10,
   -20,-10,-10,-10,-10,-10,-10,-20,
]
_ROOK = [
     0,  0,  0,  0,  0,  0,  0,  0,
     5, 10, 10, 10, 10, 10, 10,  5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
     0,  0,  0,  5,  5,  0,  0,  0,
]
_QUEEN = [
   -20,-10,-10, -5, -5,-10,-10,-20,
   -10,  0,  0,  0,  0,  0,  0,-10,
   -10,  0,  5,  5,  5,  5,  0,-10,
    -5,  0,  5,  5,  5,  5,  0, -5,
     0,  0,  5,  5,  5,  5,  0, -5,
   -10,  5,  5,  5,  5,  5,  0,-10,
   -10,  0,  5,  0,  0,  0,  0,-10,
   -20,-10,-10, -5, -5,-10,-10,-20,
]
_KING_MG = [
   -30,-40,-40,-50,-50,-40,-40,-30,
   -30,-40,-40,-50,-50,-40,-40,-30,
   -30,-40,-40,-50,-50,-40,-40,-30,
   -30,-40,-40,-50,-50,-40,-40,-30,
   -20,-30,-30,-40,-40,-30,-30,-20,
   -10,-20,-20,-20,-20,-20,-20,-10,
    20, 20,  0,  0,  0,  0, 20, 20,
    20, 30, 10,  0,  0, 10, 30, 20,
]
_KING_EG = [
   -50,-40,-30,-20,-20,-30,-40,-50,
   -30,-20,-10,  0,  0,-10,-20,-30,
   -30,-10, 20, 30, 30, 20,-10,-30,
   -30,-10, 30, 40, 40, 30,-10,-30,
   -30,-10, 30, 40, 40, 30,-10,-30,
   -30,-10, 20, 30, 30, 20,-10,-30,
   -30,-30,  0,  0,  0,  0,-30,-30,
   -50,-30,-30,-30,-30,-30,-30,-50,
]


def _to_a1_first(table):
    out = [0] * 64
    for r in range(8):
        for f in range(8):
            out[r * 8 + f] = table[(7 - r) * 8 + f]
    return out


# White tables indexed by a1-first square index (rank * 8 + file)
PST = {
    PAWN: _to_a1_first(_PAWN),
    KNIGHT: _to_a1_first(_KNIGHT),
    BISHOP: _to_a1_first(_BISHOP),
    ROOK: _to_a1_first(_ROOK),
    QUEEN: _to_a1_first(_QUEEN),
    KING: _to_a1_first(_KING_MG),
}
PST_EG = {
    PAWN: _to_a1_first(_PAWN),  # reuse MG pawn table for EG (still rewards advancement)
    KNIGHT: _to_a1_first(_KNIGHT),
    BISHOP: _to_a1_first(_BISHOP),
    ROOK: _to_a1_first(_ROOK),
    QUEEN: _to_a1_first(_QUEEN),
    KING: _to_a1_first(_KING_EG),
}

# Passed-pawn bonus by how far advanced (rank index 0..7 for White)
PASSED_BONUS = [0, 5, 10, 20, 35, 60, 100, 0]
DOUBLED_PENALTY = 12
ISOLATED_PENALTY = 14
BISHOP_PAIR_BONUS = 30
ROOK_OPEN_BONUS = 20
ROOK_SEMI_OPEN_BONUS = 10
MOBILITY_WEIGHT = {KNIGHT: 4, BISHOP: 5, ROOK: 3, QUEEN: 2}


def _square_index(sq):
    return (sq >> 4) * 8 + (sq & 7)


class Evaluator:
    """Stateless evaluator; kept as a class for potential tuning hooks."""

    def evaluate(self, board):
        squares = board.squares
        side = board.side
        mg = [0, 0]
        eg = [0, 0]
        phase = 0

        pawn_files = [{f: 0 for f in range(8)}, {f: 0 for f in range(8)}]
        our_pawns = [[], []]
        rooks = [[], []]
        bishops = [0, 0]

        # First pass: material, PST, collect pawn/rook info
        for sq in range(128):
            if sq & 0x88:
                continue
            p = squares[sq]
            if not p:
                continue
            color = p >> 3
            ptype = p & 7
            phase += PHASE_WEIGHT[ptype]
            idx = _square_index(sq)
            if color == WHITE:
                t_idx = idx
            else:
                t_idx = ((7 - (idx >> 3)) * 8) + (idx & 7)
            mg[color] += MG_VALUE[ptype] + PST[ptype][t_idx]
            eg[color] += EG_VALUE[ptype] + PST_EG[ptype][t_idx]

            if ptype == PAWN:
                pawn_files[color][sq & 7] += 1
                our_pawns[color].append(sq)
            elif ptype == ROOK:
                rooks[color].append(sq)
            elif ptype == BISHOP:
                bishops[color] += 1

        # Pawn structure
        for color in (WHITE, BLACK):
            enemy = color ^ 1
            files = pawn_files[color]
            for f in range(8):
                cnt = files[f]
                if cnt == 0:
                    continue
                if cnt > 1:
                    doubled = DOUBLED_PENALTY * (cnt - 1)
                    mg[color] -= doubled
                    eg[color] -= doubled
                # isolated
                left = files[f - 1] if f > 0 else 0
                right = files[f + 1] if f < 7 else 0
                if left == 0 and right == 0:
                    mg[color] -= ISOLATED_PENALTY
                    eg[color] -= ISOLATED_PENALTY

            for sq in our_pawns[color]:
                if self._is_passed(sq, color, our_pawns[enemy]):
                    rank = sq >> 4
                    adv = rank if color == WHITE else 7 - rank
                    mg[color] += PASSED_BONUS[adv]
                    eg[color] += PASSED_BONUS[adv] * 2

            # Bishop pair
            if bishops[color] >= 2:
                mg[color] += BISHOP_PAIR_BONUS
                eg[color] += BISHOP_PAIR_BONUS

            # Rook activity on open / semi-open files
            for sq in rooks[color]:
                f = sq & 7
                if files[f] == 0:
                    if pawn_files[enemy][f] == 0:
                        mg[color] += ROOK_OPEN_BONUS
                        eg[color] += ROOK_OPEN_BONUS
                    else:
                        mg[color] += ROOK_SEMI_OPEN_BONUS
                        eg[color] += ROOK_SEMI_OPEN_BONUS

        # King pawn shield (middlegame only)
        self._king_shield(board, mg)

        # Mobility
        self._mobility(board, mg, squares)

        # Taper
        if phase > TOTAL_PHASE:
            phase = TOTAL_PHASE
        mg_w = phase
        eg_w = TOTAL_PHASE - phase
        white = (mg[WHITE] * mg_w + eg[WHITE] * eg_w) // TOTAL_PHASE
        black = (mg[BLACK] * mg_w + eg[BLACK] * eg_w) // TOTAL_PHASE
        score = white - black
        return score if side == WHITE else -score

    def _is_passed(self, sq, color, enemy_pawns):
        f = sq & 7
        rank = sq >> 4
        for esq in enemy_pawns:
            ef = esq & 7
            if ef < f - 1 or ef > f + 1:
                continue
            erank = esq >> 4
            if color == WHITE:
                if erank > rank:
                    return False
            else:
                if erank < rank:
                    return False
        return True

    def _king_shield(self, board, mg):
        squares = board.squares
        for color in (WHITE, BLACK):
            ksq = board.king_sq[color]
            if ksq == -1:
                continue
            kf = ksq & 7
            krank = ksq >> 4
            shield = 0
            pawn = (PAWN | (color << 3))
            dir_ = 1 if color == WHITE else -1
            for df in (-1, 0, 1):
                f = kf + df
                if f < 0 or f > 7:
                    continue
                check_rank = krank + dir_
                if 0 <= check_rank <= 7:
                    s = check_rank * 16 + f
                    if squares[s] == pawn:
                        shield += 1
            bonus = shield * 8
            mg[color] += bonus

    def _mobility(self, board, mg, squares):
        for sq in range(128):
            if sq & 0x88:
                continue
            p = squares[sq]
            if not p:
                continue
            ptype = p & 7
            w = MOBILITY_WEIGHT.get(ptype)
            if not w:
                continue
            color = p >> 3
            count = 0
            if ptype == KNIGHT:
                for d in KNIGHT_OFFSETS:
                    s = sq + d
                    if not (s & 0x88) and (squares[s] == 0 or (squares[s] >> 3) != color):
                        count += 1
            elif ptype == BISHOP:
                for d in BISHOP_OFFSETS:
                    s = sq + d
                    while not (s & 0x88):
                        tp = squares[s]
                        if tp == 0:
                            count += 1
                        else:
                            if (tp >> 3) != color:
                                count += 1
                            break
                        s += d
            elif ptype == ROOK:
                for d in ROOK_OFFSETS:
                    s = sq + d
                    while not (s & 0x88):
                        tp = squares[s]
                        if tp == 0:
                            count += 1
                        else:
                            if (tp >> 3) != color:
                                count += 1
                            break
                        s += d
            elif ptype == QUEEN:
                for d in KING_OFFSETS:
                    s = sq + d
                    while not (s & 0x88):
                        tp = squares[s]
                        if tp == 0:
                            count += 1
                        else:
                            if (tp >> 3) != color:
                                count += 1
                            break
                        s += d
            mg[color] += count * w

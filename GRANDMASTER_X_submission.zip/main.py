#!/usr/bin/env python3
"""AI Knockout Chess Agent — Master Execution Entry Point.

When executed without arguments, launches the Universal Chess Interface (UCI)
on standard input / standard output for integration with tournament runners,
CuteChess, Arena, and online chess platforms:

    python main.py

Also exports choose_move from intelligence.py for programmatic harness imports.
"""

import sys
from engine.uci import main as uci_main
from intelligence import choose_move, choose_move_uci

if __name__ == "__main__":
    uci_main()

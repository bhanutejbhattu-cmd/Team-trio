"""AI Knockout Chess Tournament Interface: intelligence.py

Official Entry Point for the AI Knockout Platform.
Implements choose_move(...) with hybrid Stockfish acceleration and
rock-solid pure-Python fallback.

Guarantees:
- Strict adherence to official tournament signatures and types.
- Automatic handling of python-chess Board, custom Board, or FEN strings.
- 100% legal moves under all operational conditions.
- Safe execution in restricted sandboxes (drops to pure Python if subprocesses are disallowed).
- Resource-safe time management.
"""

import sys
from typing import Any, Optional, Union

from engine.hybrid_engine import HybridEngine, HAS_PYTHON_CHESS

if HAS_PYTHON_CHESS:
    import chess

# Global persistent hybrid engine instance
_ENGINE_INSTANCE: Optional[HybridEngine] = None


def get_engine() -> HybridEngine:
    """Retrieves or initializes the global persistent HybridEngine instance."""
    global _ENGINE_INSTANCE
    if _ENGINE_INSTANCE is None:
        # Default: 1 thread, 16MB Hash (strictly within container memory/CPU limits)
        _ENGINE_INSTANCE = HybridEngine(enable_stockfish=True, threads=1, hash_mb=16)
    return _ENGINE_INSTANCE


def choose_move(board: Any, *args, **kwargs) -> Any:
    """Official AI Knockout move selection interface.

    Accepts board representations in multiple formats:
    - python-chess Board instance
    - engine.board.Board instance
    - FEN string

    Optional keyword/positional arguments supported:
    - time_left / time_remaining: Time left on the clock in seconds or milliseconds.
    - increment: Increment per move in seconds or milliseconds.
    - depth: Optional fixed search depth.

    Returns:
        chess.Move (if python-chess is used and board is chess.Board)
        OR UCI string (e.g. 'e2e4') for FEN/generic inputs.
    """
    engine = get_engine()

    # Determine time allocation
    time_ms = 150  # Conservative default per move
    time_val = kwargs.get("time_left") or kwargs.get("time_remaining")
    if time_val is None and len(args) > 0 and isinstance(args[0], (int, float)):
        time_val = args[0]

    if time_val is not None:
        # Normalize seconds vs milliseconds
        t = float(time_val)
        if t < 60.0:  # Likely seconds
            time_ms = max(50, int(t * 1000 * 0.05))  # Allocate 5% of remaining time
        else:  # Likely milliseconds
            time_ms = max(50, int(t * 0.05))

    depth = kwargs.get("depth")

    move_uci = engine.choose_move(board, time_ms=time_ms, depth=depth)

    # Return appropriate type based on input board
    if HAS_PYTHON_CHESS and isinstance(board, chess.Board):
        if not move_uci:
            # Terminal state
            return None
        try:
            return chess.Move.from_uci(move_uci)
        except Exception:
            # Fallback to first legal move
            for m in board.legal_moves:
                return m
            return None

    return move_uci


def choose_move_uci(board: Any, *args, **kwargs) -> str:
    """Helper variant that always returns a clean UCI string (e.g. 'e2e4')."""
    res = choose_move(board, *args, **kwargs)
    if HAS_PYTHON_CHESS and isinstance(res, chess.Move):
        return res.uci()
    return str(res or "")

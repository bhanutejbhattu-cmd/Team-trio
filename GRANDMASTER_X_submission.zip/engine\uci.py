"""UCI (Universal Chess Interface) protocol adapter.

Reads UCI commands from stdin and writes responses to stdout. This is the
standard, organizer-neutral machine protocol for chess engines. If the
competition specifies a different protocol, only this file needs changing;
the engine core is protocol independent.

The search runs on a background thread so that `stop` and `isready` are
handled promptly and a legal best move is always produced.
"""

import sys
import threading
import time

from engine.board import Board, START_FEN, name_to_square
from engine.search import Search, MATE, MATE_IN_MAX
from engine.hybrid_engine import HybridEngine

ENGINE_NAME = "GRANDMASTER X"
ENGINE_AUTHOR = "AI Knockout Team"

# Move overhead (seconds) reserved for I/O and process scheduling.
MOVE_OVERHEAD = 0.030

_OUT_LOCK = threading.Lock()


def _mate_to_moves(score):
    if score > MATE_IN_MAX:
        return (MATE - score + 1) // 2
    if score < -MATE_IN_MAX:
        return -((MATE + score + 1) // 2)
    return None


class UCI:
    def __init__(self):
        self.board = Board(START_FEN)
        self.hybrid = HybridEngine(enable_stockfish=True)
        self.search = self.hybrid.pure_search
        self.thread = None
        self.searching = False

    # -- Output ------------------------------------------------------------
    @staticmethod
    def _send(line):
        with _OUT_LOCK:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()

    # -- Main loop ---------------------------------------------------------
    def loop(self):
        while True:
            try:
                line = sys.stdin.readline()
            except KeyboardInterrupt:
                break
            if not line:
                break
            line = line.strip()
            if not line:
                continue
            self.handle(line)

    def handle(self, line):
        parts = line.split()
        cmd = parts[0]
        if cmd == "uci":
            self._send("id name " + ENGINE_NAME)
            self._send("id author " + ENGINE_AUTHOR)
            self._send("option name Move Overhead type spin default 30 "
                       "min 0 max 5000")
            self._send("uciok")
        elif cmd == "isready":
            self._send("readyok")
        elif cmd == "ucinewgame":
            self._wait_search()
            self.search.new_game()
        elif cmd == "position":
            self._wait_search()
            self._cmd_position(parts)
        elif cmd == "go":
            self._start_search(parts)
        elif cmd == "stop":
            self.search.stop()
        elif cmd == "ponderhit":
            pass
        elif cmd == "quit":
            self.search.stop()
            self._wait_search(timeout=2.0)
            sys.exit(0)
        elif cmd == "d":
            self._send(self.board.fen())
        elif cmd == "perft":
            depth = int(parts[1]) if len(parts) > 1 else 1
            t = time.time()
            n = self.board.perft(depth)
            dt = time.time() - t
            self._send("perft %d = %d (%.2fs, %d nps)" % (
                depth, n, dt, int(n / dt) if dt else 0))
        elif cmd == "setoption":
            self._cmd_setoption(parts)

    def _cmd_setoption(self, parts):
        if "name" in parts and "value" in parts:
            ni = parts.index("name") + 1
            vi = parts.index("value")
            name = " ".join(parts[ni:vi])
            value = " ".join(parts[vi + 1:])
            if name.lower() == "move overhead":
                global MOVE_OVERHEAD
                try:
                    MOVE_OVERHEAD = max(0, int(value)) / 1000.0
                except ValueError:
                    pass

    def _wait_search(self, timeout=None):
        t = self.thread
        if t is not None and t.is_alive():
            t.join(timeout)

    def _cmd_position(self, parts):
        i = 1
        fen = START_FEN
        moves = []
        if len(parts) > 1 and parts[1] == "startpos":
            i = 2
        elif len(parts) > 1 and parts[1] == "fen":
            fen = " ".join(parts[2:8])
            i = 8
        if i < len(parts) and parts[i] == "moves":
            i += 1
            moves = parts[i:]
        self.board = Board(fen)
        for mv in moves:
            move = self._match_move(mv)
            if move is None:
                break
            self.board.make_move(move)

    def _match_move(self, uci):
        uci = uci.strip()
        from_sq = name_to_square(uci[0:2])
        to_sq = name_to_square(uci[2:4])
        promo = "nbrq".index(uci[4]) + 2 if len(uci) >= 5 else 0
        for m in self.board.legal_moves():
            if (m & 0x7F) == from_sq and ((m >> 7) & 0x7F) == to_sq:
                if promo == 0 or ((m >> 14) & 7) == promo:
                    return m
        return None

    def _start_search(self, parts):
        self._wait_search()
        params = {}
        i = 1
        while i < len(parts):
            key = parts[i]
            if key in ("infinite", "ponder"):
                params[key] = True
                i += 1
            elif i + 1 < len(parts):
                params[key] = int(parts[i + 1])
                i += 2
            else:
                i += 1

        board = self.board
        self.search.stopped = False
        self.searching = True
        self.thread = threading.Thread(
            target=self._run_search, args=(board, params), daemon=True)
        self.thread.start()

    def _run_search(self, board, params):
        try:
            time_ms = self._allocate_time(params, board.side)
            max_depth = params.get("depth", 64)
            node_limit = params.get("nodes")
            if "infinite" in params and "movetime" not in params \
                    and "depth" not in params:
                time_ms = None
                max_depth = 64
            t0 = time.time()

            if self.hybrid.is_stockfish_active() and "infinite" not in params:
                sf_time = time_ms if time_ms is not None else 150
                sf_depth = max_depth if "depth" in params else None
                move_uci = self.hybrid.choose_move(board.fen(), time_ms=sf_time, depth=sf_depth)
                if move_uci:
                    self._send("bestmove " + move_uci)
                    return

            def info_cb(depth, score, nodes, elapsed, pv):
                nps = int(nodes / elapsed) if elapsed > 0 else 0
                n = _mate_to_moves(score)
                score_str = ("cp %d" % score) if n is None else ("mate %d" % n)
                pv_tokens = []
                b = Board(board.fen())
                for m in pv[:16]:
                    try:
                        pv_tokens.append(b.move_to_uci(m))
                        b.make_move(m)
                    except Exception:
                        break
                pv_str = (" pv " + " ".join(pv_tokens)) if pv_tokens else ""
                self._send("info depth %d score %s nodes %d nps %d time %d%s"
                           % (depth, score_str, nodes, nps,
                              int(elapsed * 1000), pv_str))

            best = self.search.search(board, time_ms=time_ms,
                                      max_depth=max_depth,
                                      node_limit=node_limit, info_cb=info_cb)
            if best is None:
                self._send("bestmove 0000")
            else:
                self._send("bestmove " + board.move_to_uci(best))
        except Exception as exc:  # never crash the protocol
            self._send("info string error %r" % (exc,))
            legal = board.legal_moves()
            if legal:
                self._send("bestmove " + board.move_to_uci(legal[0]))
            else:
                self._send("bestmove 0000")
        finally:
            self.searching = False

    def _allocate_time(self, params, side):
        if "movetime" in params:
            return max(1, params["movetime"] - int(MOVE_OVERHEAD * 1000))
        if "depth" in params:
            return None
        remaining = params.get("wtime" if side == 0 else "btime")
        if remaining is None:
            return 1000
        inc = params.get("winc" if side == 0 else "binc", 0)
        movestogo = params.get("movestogo")
        if movestogo:
            base = remaining / max(1, movestogo)
        else:
            base = remaining / 30.0
        alloc = base + inc * 0.8
        cap = remaining * 0.35
        alloc = min(alloc, cap)
        alloc = alloc * 1000.0 - MOVE_OVERHEAD * 1000.0
        return max(5, int(alloc))


def main():
    UCI().loop()


if __name__ == "__main__":
    main()

"""Core chess board: 0x88 representation, move generation, make/unmake, FEN,
Zobrist hashing, legality, and draw detection.

Pure standard-library Python. No external dependencies.

Square encoding (0x88):
    index = rank * 16 + file
    rank 0 = rank 1 (White home), file 0 = file a.
    A square is on the board iff (sq & 0x88) == 0.

Piece encoding:
    EMPTY = 0
    White: PAWN=1, KNIGHT=2, BISHOP=3, ROOK=4, QUEEN=5, KING=6
    Black: same values ORed with 8 (e.g. black pawn = 9)
    color_of(piece) = piece >> 3      (0 = White, 1 = Black)
    type_of(piece)  = piece & 7

Move encoding (a single Python int):
    bits  0..6  : from square
    bits  7..13 : to square
    bits 14..16 : promotion piece type (0 = none, 1=N, 2=B, 3=R, 4=Q)
    bits 17..19 : flag (0 normal, 1 double push, 2 en passant,
                        3 castle king side, 4 castle queen side)
"""

import random

# --- Colors / piece types -------------------------------------------------
WHITE = 0
BLACK = 1

PAWN = 1
KNIGHT = 2
BISHOP = 3
ROOK = 4
QUEEN = 5
KING = 6

EMPTY = 0

# --- Move flags -----------------------------------------------------------
FLAG_NORMAL = 0
FLAG_DOUBLE = 1
FLAG_EP = 2
FLAG_CASTLE_K = 3
FLAG_CASTLE_Q = 4

# --- Castling rights bits -------------------------------------------------
CR_WK = 1
CR_WQ = 2
CR_BK = 4
CR_BQ = 8

START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

# --- Offset tables --------------------------------------------------------
KNIGHT_OFFSETS = (18, 33, 31, 14, -18, -33, -31, -14)
KING_OFFSETS = (16, -16, 1, -1, 17, -17, 15, -15)
BISHOP_OFFSETS = (17, -17, 15, -15)
ROOK_OFFSETS = (16, -16, 1, -1)

FILES = "abcdefgh"

# --- Zobrist keys ---------------------------------------------------------
_rng = random.Random(0xC0FFEE)
ZOBRIST = [[0] * 128 for _ in range(15)]
for _p in range(15):
    row = ZOBRIST[_p]
    for _s in range(128):
        row[_s] = _rng.getrandbits(64)
ZOBRIST_CASTLING = [_rng.getrandbits(64) for _ in range(16)]
ZOBRIST_EP = [_rng.getrandbits(64) for _ in range(8)]
ZOBRIST_SIDE = _rng.getrandbits(64)
MASK64 = 0xFFFFFFFFFFFFFFFF


# --- Move helpers ---------------------------------------------------------
def make_move_int(from_sq, to_sq, promo=0, flag=FLAG_NORMAL):
    return from_sq | (to_sq << 7) | (promo << 14) | (flag << 17)


def move_from(m):
    return m & 0x7F


def move_to(m):
    return (m >> 7) & 0x7F


def move_promo(m):
    return (m >> 14) & 7


def move_flag(m):
    return (m >> 17) & 7


def square_name(sq):
    return FILES[sq & 7] + str((sq >> 4) + 1)


def name_to_square(name):
    f = FILES.index(name[0])
    r = int(name[1]) - 1
    return r * 16 + f


def color_of(piece):
    return piece >> 3


def type_of(piece):
    return piece & 7


class Board:
    """Mutable chess position with incremental make/unmake."""

    __slots__ = ("squares", "side", "castling", "ep", "halfmove",
                 "fullmove", "king_sq", "hash", "hash_history", "undo_stack",
                 "piece_count")

    def __init__(self, fen=START_FEN):
        self.squares = [0] * 128
        self.side = WHITE
        self.castling = 0
        self.ep = -1
        self.halfmove = 0
        self.fullmove = 1
        self.king_sq = [0, 0]
        self.hash = 0
        self.hash_history = []
        self.undo_stack = []
        self.piece_count = 0
        self.set_fen(fen)

    # -- FEN ---------------------------------------------------------------
    def set_fen(self, fen):
        parts = fen.split()
        if len(parts) < 4:
            raise ValueError("Invalid FEN: %r" % (fen,))
        placement, active, castling = parts[0], parts[1], parts[2]
        ep = parts[3] if len(parts) > 3 else "-"
        half = parts[4] if len(parts) > 4 else "0"
        full = parts[5] if len(parts) > 5 else "1"

        self.squares = [0] * 128
        rank = 7
        file = 0
        for ch in placement:
            if ch == "/":
                rank -= 1
                file = 0
            elif ch.isdigit():
                file += int(ch)
            else:
                self.squares[rank * 16 + file] = _piece_from_char(ch)
                file += 1

        self.side = WHITE if active == "w" else BLACK
        self.castling = 0
        if "K" in castling:
            self.castling |= CR_WK
        if "Q" in castling:
            self.castling |= CR_WQ
        if "k" in castling:
            self.castling |= CR_BK
        if "q" in castling:
            self.castling |= CR_BQ
        self.ep = name_to_square(ep) if ep != "-" else -1
        self.halfmove = int(half)
        self.fullmove = int(full)

        self.king_sq[WHITE] = self._find_king(WHITE)
        self.king_sq[BLACK] = self._find_king(BLACK)

        self.piece_count = sum(1 for sq in range(128)
                               if not (sq & 0x88) and self.squares[sq])

        self.hash_history = []
        self.undo_stack = []
        self.hash = self._compute_hash()
        self.hash_history.append(self.hash)

    def _find_king(self, color):
        target = KING | (color << 3)
        for sq in range(128):
            if not (sq & 0x88) and self.squares[sq] == target:
                return sq
        return -1

    def _compute_hash(self):
        h = 0
        sq = 0
        squares = self.squares
        for sq in range(128):
            if sq & 0x88:
                continue
            p = squares[sq]
            if p:
                h ^= ZOBRIST[p][sq]
        h ^= ZOBRIST_CASTLING[self.castling]
        if self.ep != -1 and self._ep_possible(self.ep, self.side):
            h ^= ZOBRIST_EP[self.ep & 7]
        if self.side == BLACK:
            h ^= ZOBRIST_SIDE
        return h & MASK64

    def fen(self):
        out = []
        for rank in range(7, -1, -1):
            empty = 0
            row = []
            for file in range(8):
                p = self.squares[rank * 16 + file]
                if p == 0:
                    empty += 1
                else:
                    if empty:
                        row.append(str(empty))
                        empty = 0
                    row.append(_char_from_piece(p))
            if empty:
                row.append(str(empty))
            out.append("".join(row))
        placement = "/".join(out)

        active = "w" if self.side == WHITE else "b"
        cr = ""
        if self.castling & CR_WK:
            cr += "K"
        if self.castling & CR_WQ:
            cr += "Q"
        if self.castling & CR_BK:
            cr += "k"
        if self.castling & CR_BQ:
            cr += "q"
        if not cr:
            cr = "-"
        ep = square_name(self.ep) if self.ep != -1 else "-"
        return "%s %s %s %s %d %d" % (placement, active, cr, ep,
                                      self.halfmove, self.fullmove)

    # -- Attack detection --------------------------------------------------
    def _ep_possible(self, ep, side_to_move):
        """True if `side_to_move` has a pawn that could capture on `ep`."""
        squares = self.squares
        if side_to_move == WHITE:
            for d in (-17, -15):
                s = ep + d
                if not (s & 0x88) and squares[s] == (PAWN | (WHITE << 3)):
                    return True
        else:
            for d in (17, 15):
                s = ep + d
                if not (s & 0x88) and squares[s] == (PAWN | (BLACK << 3)):
                    return True
        return False

    def is_attacked(self, sq, by_color):
        """Is `sq` attacked by any piece of `by_color`?"""
        squares = self.squares

        # Pawns
        if by_color == WHITE:
            for d in (-17, -15):
                s = sq + d
                if not (s & 0x88) and squares[s] == (PAWN | (WHITE << 3)):
                    return True
        else:
            for d in (17, 15):
                s = sq + d
                if not (s & 0x88) and squares[s] == (PAWN | (BLACK << 3)):
                    return True

        # Knights
        kn = KNIGHT | (by_color << 3)
        for d in KNIGHT_OFFSETS:
            s = sq + d
            if not (s & 0x88) and squares[s] == kn:
                return True

        # King
        kg = KING | (by_color << 3)
        for d in KING_OFFSETS:
            s = sq + d
            if not (s & 0x88) and squares[s] == kg:
                return True

        # Diagonal sliders (bishop / queen)
        bq = (BISHOP | (by_color << 3), QUEEN | (by_color << 3))
        for d in BISHOP_OFFSETS:
            s = sq + d
            while not (s & 0x88):
                p = squares[s]
                if p:
                    if p == bq[0] or p == bq[1]:
                        return True
                    break
                s += d

        # Orthogonal sliders (rook / queen)
        rq = (ROOK | (by_color << 3), QUEEN | (by_color << 3))
        for d in ROOK_OFFSETS:
            s = sq + d
            while not (s & 0x88):
                p = squares[s]
                if p:
                    if p == rq[0] or p == rq[1]:
                        return True
                    break
                s += d
        return False

    def in_check(self, color=None):
        if color is None:
            color = self.side
        return self.is_attacked(self.king_sq[color], color ^ 1)

    # -- Move generation ---------------------------------------------------
    def generate_pseudo_moves(self):
        moves = []
        add = moves.append
        squares = self.squares
        side = self.side
        enemy = side ^ 1
        for from_sq in range(128):
            if from_sq & 0x88:
                continue
            piece = squares[from_sq]
            if not piece or (piece >> 3) != side:
                continue
            ptype = piece & 7

            if ptype == PAWN:
                if side == WHITE:
                    one = from_sq + 16
                    if squares[one] == 0:
                        if one >= 112:  # promotion rank (rank 8)
                            _add_promotions(moves, from_sq, one, FLAG_NORMAL)
                        else:
                            add(make_move_int(from_sq, one))
                            if (from_sq >> 4) == 1 and squares[from_sq + 32] == 0:
                                add(make_move_int(from_sq, from_sq + 32, 0, FLAG_DOUBLE))
                    for d in (15, 17):
                        to_sq = from_sq + d
                        if to_sq & 0x88:
                            continue
                        tp = squares[to_sq]
                        if tp and (tp >> 3) == enemy:
                            if to_sq >= 112:
                                _add_promotions(moves, from_sq, to_sq, FLAG_NORMAL)
                            else:
                                add(make_move_int(from_sq, to_sq))
                        elif to_sq == self.ep and self.ep != -1:
                            add(make_move_int(from_sq, to_sq, 0, FLAG_EP))
                else:  # BLACK
                    one = from_sq - 16
                    if squares[one] == 0:
                        if one <= 7:  # promotion rank (rank 1)
                            _add_promotions(moves, from_sq, one, FLAG_NORMAL)
                        else:
                            add(make_move_int(from_sq, one))
                            if (from_sq >> 4) == 6 and squares[from_sq - 32] == 0:
                                add(make_move_int(from_sq, from_sq - 32, 0, FLAG_DOUBLE))
                    for d in (-15, -17):
                        to_sq = from_sq + d
                        if to_sq & 0x88:
                            continue
                        tp = squares[to_sq]
                        if tp and (tp >> 3) == enemy:
                            if to_sq <= 7:
                                _add_promotions(moves, from_sq, to_sq, FLAG_NORMAL)
                            else:
                                add(make_move_int(from_sq, to_sq))
                        elif to_sq == self.ep and self.ep != -1:
                            add(make_move_int(from_sq, to_sq, 0, FLAG_EP))

            elif ptype == KNIGHT:
                for d in KNIGHT_OFFSETS:
                    to_sq = from_sq + d
                    if to_sq & 0x88:
                        continue
                    tp = squares[to_sq]
                    if tp and (tp >> 3) == side:
                        continue
                    add(make_move_int(from_sq, to_sq))

            elif ptype == KING:
                for d in KING_OFFSETS:
                    to_sq = from_sq + d
                    if to_sq & 0x88:
                        continue
                    tp = squares[to_sq]
                    if tp and (tp >> 3) == side:
                        continue
                    add(make_move_int(from_sq, to_sq))
                self._add_castles(moves, from_sq)

            else:  # sliders: BISHOP, ROOK, QUEEN
                if ptype == BISHOP:
                    dirs = BISHOP_OFFSETS
                elif ptype == ROOK:
                    dirs = ROOK_OFFSETS
                else:
                    dirs = KING_OFFSETS
                for d in dirs:
                    to_sq = from_sq + d
                    while not (to_sq & 0x88):
                        tp = squares[to_sq]
                        if tp == 0:
                            add(make_move_int(from_sq, to_sq))
                        else:
                            if (tp >> 3) == enemy:
                                add(make_move_int(from_sq, to_sq))
                            break
                        to_sq += d
        return moves

    def _add_castles(self, moves, king_from):
        side = self.side
        squares = self.squares
        enemy = side ^ 1
        if side == WHITE:
            king_home = 4
            if king_from != king_home or self.is_attacked(king_home, enemy):
                return
            if self.castling & CR_WK and squares[5] == 0 and squares[6] == 0:
                if not self.is_attacked(5, enemy) and not self.is_attacked(6, enemy):
                    moves.append(make_move_int(4, 6, 0, FLAG_CASTLE_K))
            if self.castling & CR_WQ and squares[3] == 0 and squares[2] == 0 and squares[1] == 0:
                if not self.is_attacked(3, enemy) and not self.is_attacked(2, enemy):
                    moves.append(make_move_int(4, 2, 0, FLAG_CASTLE_Q))
        else:
            king_home = 116
            if king_from != king_home or self.is_attacked(king_home, enemy):
                return
            if self.castling & CR_BK and squares[117] == 0 and squares[118] == 0:
                if not self.is_attacked(117, enemy) and not self.is_attacked(118, enemy):
                    moves.append(make_move_int(116, 118, 0, FLAG_CASTLE_K))
            if self.castling & CR_BQ and squares[115] == 0 and squares[114] == 0 and squares[113] == 0:
                if not self.is_attacked(115, enemy) and not self.is_attacked(114, enemy):
                    moves.append(make_move_int(116, 114, 0, FLAG_CASTLE_Q))

    def legal_moves(self):
        """All fully legal moves for the side to move."""
        us = self.side
        legal = []
        king_sq = self.king_sq[us]
        for m in self.generate_pseudo_moves():
            self.make_move(m)
            # after make, self.side is the opponent = us ^ 1
            if not self.is_attacked(self.king_sq[us], self.side):
                legal.append(m)
            self.unmake_move()
        return legal

    # -- Make / unmake -----------------------------------------------------
    def make_move(self, move):
        from_sq = move & 0x7F
        to_sq = (move >> 7) & 0x7F
        promo = (move >> 14) & 7
        flag = (move >> 17) & 7

        squares = self.squares
        side = self.side
        piece = squares[from_sq]
        ptype = piece & 7
        h = self.hash
        cr_old = self.castling
        ep_old = self.ep
        hm_old = self.halfmove
        full_old = self.fullmove
        old_hash = self.hash

        if flag == FLAG_EP:
            cap_sq = to_sq - 16 if side == WHITE else to_sq + 16
        else:
            cap_sq = to_sq
        captured = squares[cap_sq]

        squares[from_sq] = 0
        h ^= ZOBRIST[piece][from_sq]

        if captured:
            squares[cap_sq] = 0
            h ^= ZOBRIST[captured][cap_sq]
            self.piece_count -= 1

        if promo:
            new_piece = promo | (side << 3)
        else:
            new_piece = piece
        squares[to_sq] = new_piece
        h ^= ZOBRIST[new_piece][to_sq]

        if ptype == KING:
            self.king_sq[side] = to_sq
            if flag == FLAG_CASTLE_K:
                if side == WHITE:
                    rf, rt = 7, 5
                else:
                    rf, rt = 119, 117
                rook = squares[rf]
                squares[rf] = 0
                squares[rt] = rook
                h ^= ZOBRIST[rook][rf] ^ ZOBRIST[rook][rt]
            elif flag == FLAG_CASTLE_Q:
                if side == WHITE:
                    rf, rt = 0, 3
                else:
                    rf, rt = 112, 115
                rook = squares[rf]
                squares[rf] = 0
                squares[rt] = rook
                h ^= ZOBRIST[rook][rf] ^ ZOBRIST[rook][rt]

        # Castling rights
        cr = cr_old
        if ptype == KING:
            if side == WHITE:
                cr &= ~(CR_WK | CR_WQ)
            else:
                cr &= ~(CR_BK | CR_BQ)
        elif ptype == ROOK:
            if from_sq == 0:
                cr &= ~CR_WQ
            elif from_sq == 7:
                cr &= ~CR_WK
            elif from_sq == 112:
                cr &= ~CR_BQ
            elif from_sq == 119:
                cr &= ~CR_BK
        if cap_sq == 0:
            cr &= ~CR_WQ
        elif cap_sq == 7:
            cr &= ~CR_WK
        elif cap_sq == 112:
            cr &= ~CR_BQ
        elif cap_sq == 119:
            cr &= ~CR_BK
        self.castling = cr
        h ^= ZOBRIST_CASTLING[cr_old] ^ ZOBRIST_CASTLING[cr]

        # En passant target
        if flag == FLAG_DOUBLE:
            ep = (from_sq + to_sq) >> 1
        else:
            ep = -1
        if ep_old != -1 and self._ep_possible(ep_old, side):
            h ^= ZOBRIST_EP[ep_old & 7]
        self.ep = ep
        if ep != -1 and self._ep_possible(ep, side ^ 1):
            h ^= ZOBRIST_EP[ep & 7]

        if ptype == PAWN or captured:
            self.halfmove = 0
        else:
            self.halfmove = hm_old + 1
        if side == BLACK:
            self.fullmove = full_old + 1

        self.side = side ^ 1
        h ^= ZOBRIST_SIDE
        h &= MASK64
        self.hash = h
        self.hash_history.append(h)
        self.undo_stack.append((move, captured, cap_sq, cr_old, ep_old,
                                hm_old, full_old, old_hash))

    def unmake_move(self):
        (move, captured, cap_sq, cr_old, ep_old, hm_old, full_old,
         old_hash) = self.undo_stack.pop()
        self.hash_history.pop()

        from_sq = move & 0x7F
        to_sq = (move >> 7) & 0x7F
        promo = (move >> 14) & 7
        flag = (move >> 17) & 7

        side = self.side ^ 1
        squares = self.squares
        moved = squares[to_sq]

        if promo:
            squares[from_sq] = PAWN | (side << 3)
        else:
            squares[from_sq] = moved
        squares[to_sq] = 0
        if captured:
            squares[cap_sq] = captured
            self.piece_count += 1

        if flag == FLAG_CASTLE_K:
            if side == WHITE:
                rf, rt = 7, 5
            else:
                rf, rt = 119, 117
            squares[rf] = squares[rt]
            squares[rt] = 0
        elif flag == FLAG_CASTLE_Q:
            if side == WHITE:
                rf, rt = 0, 3
            else:
                rf, rt = 112, 115
            squares[rf] = squares[rt]
            squares[rt] = 0

        if (moved & 7) == KING:
            self.king_sq[side] = from_sq

        self.castling = cr_old
        self.ep = ep_old
        self.halfmove = hm_old
        self.fullmove = full_old
        self.side = side
        self.hash = old_hash

    # -- Null move (for search pruning) -----------------------------------
    def make_null(self):
        self.undo_stack.append((None, 0, -1, self.castling, self.ep,
                                self.halfmove, self.fullmove, self.hash))
        h = self.hash
        if self.ep != -1 and self._ep_possible(self.ep, self.side):
            h ^= ZOBRIST_EP[self.ep & 7]
        self.ep = -1
        self.side ^= 1
        h ^= ZOBRIST_SIDE
        self.hash = h & MASK64
        self.halfmove += 1

    def unmake_null(self):
        (_, _, _, cr, ep, hm, full, old_hash) = self.undo_stack.pop()
        self.castling = cr
        self.ep = ep
        self.halfmove = hm
        self.fullmove = full
        self.hash = old_hash
        self.side ^= 1

    # -- Terminal / draw detection ----------------------------------------
    def has_legal_move(self):
        us = self.side
        for m in self.generate_pseudo_moves():
            self.make_move(m)
            ok = not self.is_attacked(self.king_sq[us], self.side)
            self.unmake_move()
            if ok:
                return True
        return False

    def is_checkmate(self):
        return self.in_check() and not self.has_legal_move()

    def is_stalemate(self):
        return (not self.in_check()) and not self.has_legal_move()

    def is_insufficient_material(self):
        """Basic dead-position material detection."""
        squares = self.squares
        pieces = {WHITE: [], BLACK: []}
        for sq in range(128):
            if sq & 0x88:
                continue
            p = squares[sq]
            if p and (p & 7) != KING:
                pieces[p >> 3].append(p & 7)

        wp = pieces[WHITE]
        bp = pieces[BLACK]

        if not wp and not bp:
            return True
        # K + minor vs K
        if len(wp) == 1 and not bp and wp[0] in (BISHOP, KNIGHT):
            return True
        if len(bp) == 1 and not wp and bp[0] in (BISHOP, KNIGHT):
            return True
        # K+B vs K+B with same-colored bishops
        if (len(wp) == 1 and len(bp) == 1 and wp[0] == BISHOP and bp[0] == BISHOP):
            wb = self._first_square_of(WHITE, BISHOP)
            bb = self._first_square_of(BLACK, BISHOP)
            if wb != -1 and bb != -1:
                if ((wb >> 4) + (wb & 7)) % 2 == ((bb >> 4) + (bb & 7)) % 2:
                    return True
        return False

    def _first_square_of(self, color, ptype):
        target = ptype | (color << 3)
        for sq in range(128):
            if not (sq & 0x88) and self.squares[sq] == target:
                return sq
        return -1

    def is_repetition(self, threshold=1):
        """True if current position appeared at least `threshold` times
        previously (within the current irreversible-move window)."""
        h = self.hash
        hist = self.hash_history
        n = len(hist)
        count = 0
        # Only positions since the last irreversible move can repeat; step 2.
        limit = self.halfmove
        i = n - 3
        steps = 0
        while i >= 0 and steps <= limit:
            if hist[i] == h:
                count += 1
                if count >= threshold:
                    return True
            i -= 2
            steps += 2
        return False

    def is_draw(self):
        if self.is_insufficient_material():
            return True
        if self.halfmove >= 100:
            return True
        if self.is_repetition(threshold=1):
            return True
        return False

    def is_game_over(self):
        if not self.has_legal_move():
            return True
        if self.is_draw():
            return True
        return False

    def game_result(self):
        """Returns '1-0', '0-1', '1/2-1/2', or '*' for ongoing."""
        if not self.has_legal_move():
            if self.in_check():
                return "0-1" if self.side == WHITE else "1-0"
            return "1/2-1/2"
        if self.is_draw():
            return "1/2-1/2"
        return "*"

    # -- Perft -------------------------------------------------------------
    def perft(self, depth):
        if depth == 0:
            return 1
        total = 0
        for m in self.generate_pseudo_moves():
            self.make_move(m)
            us = self.side ^ 1
            if not self.is_attacked(self.king_sq[us], self.side):
                total += self.perft(depth - 1)
            self.unmake_move()
        return total

    def perft_divide(self, depth):
        result = {}
        for m in self.generate_pseudo_moves():
            self.make_move(m)
            us = self.side ^ 1
            if not self.is_attacked(self.king_sq[us], self.side):
                result[self.move_to_uci(m)] = self.perft(depth - 1)
            self.unmake_move()
        return result

    # -- Notation ----------------------------------------------------------
    def move_to_uci(self, move):
        s = square_name(move & 0x7F) + square_name((move >> 7) & 0x7F)
        promo = (move >> 14) & 7
        if promo:
            s += "nbrq"[promo - 2]
        return s

    def parse_uci(self, uci):
        uci = uci.strip()
        from_sq = name_to_square(uci[0:2])
        to_sq = name_to_square(uci[2:4])
        promo = 0
        if len(uci) >= 5:
            promo = "nbrq".index(uci[4]) + 2
        piece = self.squares[from_sq]
        ptype = piece & 7
        flag = FLAG_NORMAL
        if ptype == KING and abs((to_sq & 7) - (from_sq & 7)) == 2:
            flag = FLAG_CASTLE_K if (to_sq & 7) > (from_sq & 7) else FLAG_CASTLE_Q
        elif ptype == PAWN:
            if to_sq == self.ep and (from_sq & 7) != (to_sq & 7):
                flag = FLAG_EP
            elif abs((to_sq >> 4) - (from_sq >> 4)) == 2:
                flag = FLAG_DOUBLE
        return make_move_int(from_sq, to_sq, promo, flag)

    def move_to_san(self, move):
        from_sq = move & 0x7F
        to_sq = (move >> 7) & 0x7F
        promo = (move >> 14) & 7
        flag = (move >> 17) & 7
        piece = self.squares[from_sq]
        ptype = piece & 7

        if flag == FLAG_CASTLE_K:
            san = "O-O"
        elif flag == FLAG_CASTLE_Q:
            san = "O-O-O"
        else:
            is_capture = (self.squares[to_sq] != 0) or (flag == FLAG_EP)
            if ptype == PAWN:
                if is_capture:
                    san = FILES[from_sq & 7] + "x" + square_name(to_sq)
                else:
                    san = square_name(to_sq)
                if promo:
                    san += "=" + "NBRQ"[promo - 2]
            else:
                piece_letter = "  NBRQK"[ptype]
                # disambiguation
                same = []
                for m in self.legal_moves():
                    if m == move:
                        continue
                    if (m & 7) == 0:
                        continue
                    if ((m >> 7) & 0x7F) != to_sq:
                        continue
                    op = self.squares[m & 0x7F]
                    if op == piece:
                        same.append(m & 0x7F)
                disamb = ""
                if same:
                    same_files = any((s & 7) == (from_sq & 7) for s in same)
                    same_ranks = any((s >> 4) == (from_sq >> 4) for s in same)
                    if not same_files:
                        disamb = FILES[from_sq & 7]
                    elif not same_ranks:
                        disamb = str((from_sq >> 4) + 1)
                    else:
                        disamb = square_name(from_sq)
                san = piece_letter + disamb + ("x" if is_capture else "") + square_name(to_sq)

        self.make_move(move)
        if self.in_check():
            san += "#" if not self.has_legal_move() else "+"
        self.unmake_move()
        return san


def _add_promotions(moves, from_sq, to_sq, flag):
    for promo in (QUEEN, ROOK, BISHOP, KNIGHT):
        moves.append(make_move_int(from_sq, to_sq, promo, flag))


def _piece_from_char(ch):
    table = {
        "P": PAWN, "N": KNIGHT, "B": BISHOP, "R": ROOK, "Q": QUEEN, "K": KING,
        "p": PAWN | 8, "n": KNIGHT | 8, "b": BISHOP | 8, "r": ROOK | 8,
        "q": QUEEN | 8, "k": KING | 8,
    }
    return table[ch]


def _char_from_piece(p):
    table = {
        PAWN: "P", KNIGHT: "N", BISHOP: "B", ROOK: "R", QUEEN: "Q", KING: "K",
    }
    c = table[p & 7]
    return c if (p >> 3) == WHITE else c.lower()

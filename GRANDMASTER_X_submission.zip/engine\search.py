"""Search engine: negamax + alpha-beta, transposition table, quiescence
search, move ordering (TT / MVV-LVA / killers / history), null-move
pruning, late move reductions, iterative deepening, aspiration windows,
and time management.

Pure standard-library Python.
"""

import time

from engine.board import PAWN, KING, FLAG_EP
from engine.evaluate import Evaluator, MG_VALUE

MATE = 30000
MATE_IN_MAX = MATE - 256
INF = 40000
MAX_PLY = 128

TT_EXACT = 0
TT_LOWER = 1
TT_UPPER = 2


class TimeUp(Exception):
    pass


class Search:
    def __init__(self, tt_size=1_000_000):
        self.board = None
        self.eval = Evaluator()
        self.tt = {}
        self.tt_size = tt_size
        self.killers = [[0, 0] for _ in range(MAX_PLY + 2)]
        self.history = [[[0] * 128 for _ in range(128)] for _ in range(2)]
        self.nodes = 0
        self.deadline = 0.0
        self.node_limit = None
        self.stopped = False
        self._root_best = None
        self._pv = []
        self.last_score = 0
        self.last_depth = 0

    # -- Public API --------------------------------------------------------
    def new_game(self):
        self.tt.clear()
        self.killers = [[0, 0] for _ in range(MAX_PLY + 2)]
        self.history = [[[0] * 128 for _ in range(128)] for _ in range(2)]

    def search(self, board, time_ms=None, max_depth=64, node_limit=None,
               info_cb=None):
        """Return the best move (int) for `board`.

        time_ms: soft budget in milliseconds. None => use max_depth only.
        node_limit: stop after this many nodes if not None.
        info_cb: optional callback(depth, score, nodes, elapsed, pv_moves).
        """
        self.board = board
        self.nodes = 0
        self.stopped = False
        self.node_limit = node_limit
        if time_ms is not None:
            self.deadline = time.time() + (time_ms / 1000.0)
        else:
            self.deadline = None

        legal = board.legal_moves()
        if not legal:
            return None
        if len(legal) == 1:
            return legal[0]

        best_move = legal[0]
        best_score = -INF
        self._root_best = best_move
        prev_score = 0
        t0 = time.time()
        completed_depth = 0

        for depth in range(1, max_depth + 1):
            try:
                score, move = self._iterate(depth, prev_score)
            except TimeUp:
                break
            best_move = move
            best_score = score
            prev_score = score
            completed_depth = depth
            elapsed = time.time() - t0
            if info_cb:
                info_cb(depth, score, self.nodes, elapsed, list(self._pv))
            if abs(score) >= MATE_IN_MAX:
                break
            if time_ms is not None and self.deadline is not None:
                # don't start a new iteration if we're already close
                if time.time() > self.deadline - 0.5 * (self.deadline - t0) \
                        and depth >= 2:
                    break
        self._root_best = best_move
        self.last_score = best_score
        self.last_depth = completed_depth
        return best_move

    def _iterate(self, depth, prev_score):
        board = self.board
        self._pv = []
        # Aspiration windows
        if depth >= 3 and abs(prev_score) < MATE_IN_MAX:
            delta = 22
            alpha = max(-INF, prev_score - delta)
            beta = min(INF, prev_score + delta)
            while True:
                score, move = self._root_search(depth, alpha, beta)
                if score <= alpha:
                    alpha = max(-INF, alpha - delta)
                    delta *= 2
                elif score >= beta:
                    beta = min(INF, beta + delta)
                    delta *= 2
                else:
                    break
            return score, move
        return self._root_search(depth, -INF, INF)

    # -- Root --------------------------------------------------------------
    def _root_search(self, depth, alpha, beta):
        board = self.board
        us = board.side
        entry = self.tt.get(board.hash)
        tt_move = entry[3] if entry else 0

        moves = board.legal_moves()
        moves = self._order_moves(board, moves, tt_move, 0, us)

        best_move = moves[0]
        best_score = -INF
        alpha_orig = alpha
        pv_here = []

        for idx, m in enumerate(moves):
            is_quiet = self._is_quiet(board, m)
            board.make_move(m)
            try:
                if idx == 0:
                    score = -self._negamax(depth - 1, -beta, -alpha, 1)
                else:
                    score = -self._negamax(depth - 1, -alpha - 1, -alpha, 1)
                    if score > alpha:
                        score = -self._negamax(depth - 1, -beta, -alpha, 1)
            finally:
                board.unmake_move()

            if score > best_score:
                best_score = score
                best_move = m
                if score > alpha:
                    alpha = score
                    if alpha >= beta:
                        if is_quiet:
                            self._store_killer(0, m)
                            self.history[us][m & 0x7F][(m >> 7) & 0x7F] += \
                                depth * depth
                        break

        # Store in TT
        flag = TT_EXACT
        if best_score <= alpha_orig:
            flag = TT_UPPER
        elif best_score >= beta:
            flag = TT_LOWER
        self._tt_store(board.hash, depth, best_score, flag, best_move, 0)

        self._pv = [best_move]
        return best_score, best_move

    # -- Negamax -----------------------------------------------------------
    def _negamax(self, depth, alpha, beta, ply):
        self.nodes += 1
        if (self.nodes & 511) == 0:
            self._check_time()
        board = self.board

        if ply >= MAX_PLY:
            return self.eval.evaluate(board)

        # Draw detection
        if ply > 0:
            if board.is_repetition(1) or board.halfmove >= 100:
                return 0
            if board.piece_count <= 4 and board.is_insufficient_material():
                return 0

        alpha_orig = alpha
        key = board.hash
        tt_move = 0
        entry = self.tt.get(key)
        if entry is not None:
            e_depth, e_score, e_flag, e_move = entry
            tt_move = e_move
            if e_depth >= depth and ply > 0:
                score = e_score
                if score > MATE_IN_MAX:
                    score -= ply
                elif score < -MATE_IN_MAX:
                    score += ply
                if e_flag == TT_EXACT:
                    return score
                if e_flag == TT_LOWER:
                    if score > alpha:
                        alpha = score
                elif e_flag == TT_UPPER:
                    if score < beta:
                        beta = score
                if alpha >= beta:
                    return score

        in_check = board.in_check()
        if in_check:
            depth += 1
        if depth <= 0:
            return self._quiescence(alpha, beta, ply)

        static_eval = self.eval.evaluate(board)

        # Reverse futility pruning
        if (not in_check and depth <= 3 and abs(beta) < MATE_IN_MAX
                and static_eval - 130 * depth >= beta):
            return static_eval

        # Razoring
        if (not in_check and depth <= 2 and abs(alpha) < MATE_IN_MAX
                and static_eval + 200 * depth < alpha):
            qs = self._quiescence(alpha, beta, ply)
            if qs < alpha:
                return qs

        # Null-move pruning
        if (not in_check and depth >= 3 and beta < MATE_IN_MAX
                and self._has_non_pawn(board, board.side)):
            r = 2 + depth // 4
            board.make_null()
            try:
                score = -self._negamax(depth - 1 - r, -beta, -beta + 1, ply + 1)
            finally:
                board.unmake_null()
            if score >= beta:
                if score > MATE_IN_MAX:
                    score = beta
                return score

        us = board.side
        moves = board.generate_pseudo_moves()
        moves = self._order_moves(board, moves, tt_move, ply, us)

        best_score = -INF
        best_move = 0
        legal = 0
        for m in moves:
            is_quiet = self._is_quiet(board, m)
            board.make_move(m)
            if board.is_attacked(board.king_sq[us], board.side):
                board.unmake_move()
                continue
            legal += 1

            try:
                new_depth = depth - 1
                if legal == 1:
                    score = -self._negamax(new_depth, -beta, -alpha, ply + 1)
                else:
                    r = 0
                    if (depth >= 3 and is_quiet and not in_check and legal > 3):
                        r = 1
                        if legal > 6:
                            r += 1
                        if depth >= 6:
                            r += 1
                    if r > 0:
                        score = -self._negamax(new_depth - r, -alpha - 1, -alpha,
                                                ply + 1)
                    else:
                        score = -self._negamax(new_depth, -alpha - 1, -alpha,
                                                ply + 1)
                    if score > alpha and score < beta:
                        score = -self._negamax(new_depth, -beta, -alpha, ply + 1)
            finally:
                board.unmake_move()

            if score > best_score:
                best_score = score
                best_move = m
                if score > alpha:
                    alpha = score
                    if alpha >= beta:
                        if is_quiet:
                            self._store_killer(ply, m)
                            self.history[us][m & 0x7F][(m >> 7) & 0x7F] += \
                                depth * depth
                        break

        if legal == 0:
            return -MATE + ply if in_check else 0

        flag = TT_EXACT
        if best_score <= alpha_orig:
            flag = TT_UPPER
        elif best_score >= beta:
            flag = TT_LOWER
        self._tt_store(key, depth, best_score, flag, best_move, ply)
        return best_score

    # -- Quiescence --------------------------------------------------------
    def _quiescence(self, alpha, beta, ply):
        self.nodes += 1
        if (self.nodes & 511) == 0:
            self._check_time()
        board = self.board
        if ply >= MAX_PLY:
            return self.eval.evaluate(board)

        in_check = board.in_check()
        if not in_check:
            stand = self.eval.evaluate(board)
            if stand >= beta:
                return stand
            if stand > alpha:
                alpha = stand
        else:
            stand = -INF

        us = board.side
        moves = board.generate_pseudo_moves()
        scored = []
        for m in moves:
            to_sq = (m >> 7) & 0x7F
            flag = (m >> 17) & 7
            promo = (m >> 14) & 7
            victim = board.squares[to_sq]
            if flag == FLAG_EP:
                score = 1_000_000 + MG_VALUE[PAWN]
            elif victim:
                attacker = board.squares[m & 0x7F] & 7
                score = 1_000_000 + MG_VALUE.get(victim & 7, 0) * 16 \
                    - MG_VALUE.get(attacker, 0)
            elif promo:
                score = 900_000 + promo
            else:
                if not in_check:
                    continue
                score = 0
            if not in_check and victim:
                # delta pruning
                gain = MG_VALUE.get(victim & 7, 0)
                if stand + gain + 200 < alpha:
                    continue
            scored.append((score, m))

        scored.sort(key=lambda x: x[0], reverse=True)

        best_score = stand
        legal = 0
        for _, m in scored:
            board.make_move(m)
            if board.is_attacked(board.king_sq[us], board.side):
                board.unmake_move()
                continue
            legal += 1
            try:
                score = -self._quiescence(-beta, -alpha, ply + 1)
            finally:
                board.unmake_move()
            if score > best_score:
                best_score = score
                if score > alpha:
                    alpha = score
                    if alpha >= beta:
                        break

        if in_check and legal == 0:
            return -MATE + ply
        return best_score

    # -- Move ordering -----------------------------------------------------
    def _order_moves(self, board, moves, tt_move, ply, us):
        squares = board.squares
        hist = self.history[us]
        k0, k1 = self.killers[ply]
        scored = []
        append = scored.append
        for m in moves:
            if m == tt_move:
                append((2_000_000, m))
                continue
            to_sq = (m >> 7) & 0x7F
            from_sq = m & 0x7F
            promo = (m >> 14) & 7
            flag = (m >> 17) & 7
            victim = squares[to_sq]
            if flag == FLAG_EP:
                append((1_050_000, m))
            elif victim:
                attacker = squares[from_sq] & 7
                append((1_000_000 + MG_VALUE.get(victim & 7, 0) * 16
                        - MG_VALUE.get(attacker, 0), m))
            elif promo:
                append((900_000 + promo, m))
            elif m == k0:
                append((800_000, m))
            elif m == k1:
                append((790_000, m))
            else:
                append((hist[from_sq][to_sq], m))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [m for _, m in scored]

    def _store_killer(self, ply, move):
        k = self.killers[ply]
        if k[0] != move:
            k[1] = k[0]
            k[0] = move

    @staticmethod
    def _is_quiet(board, m):
        if (m >> 14) & 7:
            return False
        if ((m >> 17) & 7) == FLAG_EP:
            return False
        return board.squares[(m >> 7) & 0x7F] == 0

    @staticmethod
    def _has_non_pawn(board, side):
        target = side << 3
        squares = board.squares
        for sq in range(128):
            if sq & 0x88:
                continue
            p = squares[sq]
            if p and (p >> 3) == side:
                t = p & 7
                if t != PAWN and t != KING:
                    return True
        return False

    # -- TT helpers --------------------------------------------------------
    def _tt_store(self, key, depth, score, flag, move, ply):
        if len(self.tt) >= self.tt_size:
            self.tt.clear()
        store = score
        if store > MATE_IN_MAX:
            store += ply
        elif store < -MATE_IN_MAX:
            store -= ply
        self.tt[key] = (depth, store, flag, move)

    # -- Time --------------------------------------------------------------
    def _check_time(self):
        if self.stopped:
            raise TimeUp()
        if self.node_limit is not None and self.nodes >= self.node_limit:
            raise TimeUp()
        if self.deadline is not None and time.time() >= self.deadline:
            raise TimeUp()

    def stop(self):
        self.stopped = True

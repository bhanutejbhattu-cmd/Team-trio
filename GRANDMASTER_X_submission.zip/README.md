# GRANDMASTER X — AI Knockout Chess Bot

A tournament-grade, hybrid autonomous chess bot engineered for the **AI Knockout Platform**.

## Architecture Overview
- **Dual Interface**:
  - `intelligence.py`: `choose_move(board, ...)` Python function interface.
  - `main.py`: Full UCI protocol interface for stdin/stdout tournament harnesses.
- **Hybrid Engine**:
  - **Primary**: Stockfish UCI acceleration (using local or system Stockfish).
  - **Fallback**: Built-in pure-Python 0x88 board + Negamax + Alpha-Beta pruning + Transposition Table + Quiescence search engine.
- **Fail-Safe Guarantee**:
  - Automatically recovers from missing binaries, architecture mismatches (Windows vs Linux container), subprocess timeouts, and sandbox restrictions.
  - 100% legal moves under all operational conditions.

## Execution
```bash
# UCI Mode
python main.py

# Function / Module Import
from intelligence import choose_move
```

## Running Tests
```bash
python -m pytest tests -v
```

"""AI KNOCOUT chess engine package."""

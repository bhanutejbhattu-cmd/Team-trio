"""Stockfish UCI protocol adapter with thread-safe non-blocking I/O and process supervision.

Safely communicates with an external Stockfish executable via standard UCI protocol.
Handles missing binaries, incompatible architectures, timeouts, and process crashes.
"""

import os
import sys
import shutil
import subprocess
import threading
import time
import queue
from typing import Optional, List, Tuple


class StockfishError(Exception):
    """Raised when Stockfish fails to execute, times out, or produces invalid output."""
    pass


class StockfishAdapter:
    """Manages an external Stockfish process via the Universal Chess Interface (UCI)."""

    def __init__(self, binary_path: Optional[str] = None, threads: int = 1, hash_mb: int = 16):
        self.requested_path = binary_path
        self.threads = max(1, threads)
        self.hash_mb = max(4, hash_mb)
        self.binary_path = self._resolve_binary(binary_path)
        self.process: Optional[subprocess.Popen] = None
        self.engine_name = "Unknown"
        self._lock = threading.RLock()
        self._is_ready = False
        self._line_queue: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None

    @staticmethod
    def _resolve_binary(candidate_path: Optional[str]) -> Optional[str]:
        """Locates a viable Stockfish executable on the system."""
        if candidate_path:
            if os.path.isfile(candidate_path):
                return os.path.abspath(candidate_path)
            return None

        # Environment variable override
        env_path = os.environ.get("STOCKFISH_PATH")
        if env_path and os.path.isfile(env_path):
            return os.path.abspath(env_path)

        # Workspace relative paths
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        bin_dir = os.path.join(base_dir, "bin")
        candidates = []
        if sys.platform == "win32":
            candidates.extend([
                os.path.join(bin_dir, "stockfish.exe"),
                os.path.join(base_dir, "stockfish.exe"),
                os.path.join(bin_dir, "stockfish-windows-x86-64-universal.exe"),
            ])
        else:
            candidates.extend([
                os.path.join(bin_dir, "stockfish"),
                os.path.join(base_dir, "stockfish"),
                "/usr/games/stockfish",
                "/usr/bin/stockfish",
                "/usr/local/bin/stockfish",
            ])

        # System PATH lookup
        found = shutil.which("stockfish") or (shutil.which("stockfish.exe") if sys.platform == "win32" else None)
        if found:
            candidates.append(found)

        for p in candidates:
            if p and os.path.isfile(p):
                if sys.platform != "win32" and p.lower().endswith(".exe"):
                    continue
                return os.path.abspath(p)

        return None

    def is_available(self) -> bool:
        """Verifies if the binary exists and passes a basic UCI handshake."""
        if not self.binary_path or not os.path.isfile(self.binary_path):
            return False
        try:
            name = self._probe()
            if name:
                self.engine_name = name
                return True
        except Exception:
            return False
        return False

    def _probe(self) -> Optional[str]:
        """Runs a quick one-shot probe to verify engine responsiveness and get version."""
        p = subprocess.Popen(
            [self.binary_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        try:
            out, _ = p.communicate("uci\nquit\n", timeout=2.0)
            engine_name = None
            has_uciok = False
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("id name "):
                    engine_name = line[8:].strip()
                elif line == "uciok":
                    has_uciok = True
            if has_uciok:
                return engine_name or "Stockfish"
        except (subprocess.TimeoutExpired, OSError):
            p.kill()
            return None
        return None

    def _start_reader(self):
        """Starts a background daemon thread that feeds process stdout into a thread-safe Queue."""
        self._line_queue = queue.Queue()

        def _reader():
            try:
                for line in iter(self.process.stdout.readline, ''):
                    if not line:
                        break
                    self._line_queue.put(line.strip())
            except Exception:
                pass

        self._reader_thread = threading.Thread(target=_reader, daemon=True)
        self._reader_thread.start()

    def start(self) -> bool:
        """Starts a persistent Stockfish process and initializes UCI settings."""
        with self._lock:
            if self.process and self.process.poll() is None:
                return True

            if not self.binary_path or not os.path.isfile(self.binary_path):
                raise StockfishError(f"Stockfish binary not found at: {self.binary_path}")

            try:
                self.process = subprocess.Popen(
                    [self.binary_path],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                )
            except OSError as err:
                raise StockfishError(f"Failed to spawn Stockfish process: {err}")

            self._start_reader()

            self._send_command("uci")
            engine_name, uciok = self._read_until(["uciok"], timeout=3.0)
            if not uciok:
                self.stop()
                raise StockfishError("Stockfish failed to respond with uciok")

            for l in engine_name:
                if l.startswith("id name "):
                    self.engine_name = l[8:].strip()

            self._send_command(f"setoption name Threads value {self.threads}")
            self._send_command(f"setoption name Hash value {self.hash_mb}")
            self._send_command("isready")
            _, readyok = self._read_until(["readyok"], timeout=3.0)
            if not readyok:
                self.stop()
                raise StockfishError("Stockfish failed to respond with readyok")

            self._is_ready = True
            return True

    def _send_command(self, cmd: str) -> None:
        if not self.process or self.process.poll() is not None:
            raise StockfishError("Stockfish process is not running")
        try:
            self.process.stdin.write(cmd + "\n")
            self.process.stdin.flush()
        except (OSError, BrokenPipeError) as err:
            raise StockfishError(f"Failed writing command to Stockfish: {err}")

    def _read_until(self, target_keywords: List[str], timeout: float = 3.0) -> Tuple[List[str], bool]:
        """Reads lines non-blockingly from queue until any target keyword matches or timeout expires."""
        lines = []
        deadline = time.time() + timeout
        while time.time() < deadline:
            remaining = max(0.01, deadline - time.time())
            try:
                line = self._line_queue.get(timeout=remaining)
                lines.append(line)
                if any(line.startswith(kw) or line == kw for kw in target_keywords):
                    return lines, True
            except queue.Empty:
                break
        return lines, False

    def get_best_move(self, fen: str, movetime_ms: int = 100, depth: Optional[int] = None) -> str:
        """Asks Stockfish for the best move in UCI format (e.g. 'e2e4')."""
        with self._lock:
            if not self.process or self.process.poll() is not None:
                self.start()

            # Drain any stale lines in queue
            while not self._line_queue.empty():
                try:
                    self._line_queue.get_nowait()
                except queue.Empty:
                    break

            # Set position
            self._send_command(f"position fen {fen}")

            # Send search command
            if depth is not None and depth > 0:
                self._send_command(f"go depth {depth}")
                timeout = max(3.0, (movetime_ms / 1000.0) * 2.0)
            else:
                effective_ms = max(10, movetime_ms)
                self._send_command(f"go movetime {effective_ms}")
                timeout = max(1.0, (effective_ms / 1000.0) + 1.5)

            lines, found = self._read_until(["bestmove"], timeout=timeout)
            if not found:
                self.stop()
                raise StockfishError(f"Stockfish timed out after {timeout:.2f}s waiting for bestmove")

            for line in reversed(lines):
                if line.startswith("bestmove"):
                    parts = line.split()
                    if len(parts) >= 2:
                        bestmove = parts[1]
                        if bestmove not in ("(none)", "NULL", "0000"):
                            return bestmove
                    raise StockfishError(f"Stockfish returned no legal move: '{line}'")

            raise StockfishError("Stockfish response did not contain a valid bestmove token")

    def stop(self) -> None:
        """Cleanly terminates the Stockfish process."""
        with self._lock:
            self._is_ready = False
            if self.process:
                try:
                    self.process.stdin.write("quit\n")
                    self.process.stdin.flush()
                    self.process.wait(timeout=0.5)
                except Exception:
                    try:
                        self.process.kill()
                    except Exception:
                        pass
                try:
                    if self.process.stdout:
                        self.process.stdout.close()
                    if self.process.stdin:
                        self.process.stdin.close()
                    if self.process.stderr:
                        self.process.stderr.close()
                except Exception:
                    pass
                self.process = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
